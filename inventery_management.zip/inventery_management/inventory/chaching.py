from django.core.cache import cache
from .models import Item

def get_cached_item(item_id):
    item = cache.get(f'item_{item_id}')
    if not item:
        item = Item.objects.get(id=item_id)
        cache.set(f'item_{item_id}', item)
    return item
