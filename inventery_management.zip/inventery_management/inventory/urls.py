from django.urls import path
from .views import create_item, get_item, update_item, delete_item,register_user,login_user
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

urlpatterns = [
    path('items/', create_item, name='create_item'),
    path('items/<int:item_id>/', get_item, name='get_item'),  # For GET
    path('items/<int:item_id>/', update_item, name='update_item'),  # For PUT
    path('items/<int:item_id>/', delete_item, name='delete_item'),  # For DELETE
    path('register/', register_user, name='register_user'),
    path('login/', login_user, name='login_user'),
]



urlpatterns += [
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]